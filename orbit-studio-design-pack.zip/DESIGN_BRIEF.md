# Orbit Studio UI Redesign Brief

Orbit Studio is a local web app that turns Insta360 X4 Air footage into fly-through 3D Gaussian Splat scenes. The entire front end is the single file index.html in this pack (inline CSS and JS, no build step, Chrome and Edge on Windows, served at localhost:7360). The app works. The visual layer needs a spatial-layout pass worthy of a flagship iOS app.

## Observed spatial issues, in priority order

1. Disconnected page grid. The large page title (Create, Library) sits at the top left of the viewport while the content column is centered, so title and content never share an axis. Establish one content container (max-width around 1080px, centered) that both the large title and the body content align to, with the title collapsing into the compact glass bar on scroll.
2. Bottom tab bar clipping. The floating glass tab bar renders partially below the fold at 1080p and content behind it has no bottom clearance. The tab bar must always sit fully inside the viewport with a fixed bottom offset around 20px, and every scroll container needs bottom padding of tab bar height plus 32px so content never hides beneath it.
3. Wizard column floats on a void. Step content (progress capsule, step label, heading, inputs, drop zone) has no surface. Wrap each wizard step in an elevated card (radius 20px, subtle border, dark elevated fill) with consistent internal padding on an 8pt grid, and tighten the vertical rhythm: progress capsule, step label, and heading currently read as three unrelated elements.
4. Settings sheet value overflow. Long values (the full ffmpeg version banner) wrap to multiple ragged right-aligned lines. Row layout should be a two-column grid: label left, value right, value single-line with ellipsis truncation and title attribute for the full string. Version strings should be shortened to the semantic part (8.1.2 essentials).
5. Continue button placement. The primary action floats at the column's right edge, far from the inputs after the tall drop zone. Anchor a right-aligned action row inside the step card with consistent top spacing, and consider a disabled state explanation inline.
6. Excess dead space and weak surface hierarchy in dark mode. Pure black background plus barely visible card borders reads as emptiness. Use layered surfaces: background #000, elevated card #1C1C1E, second elevation #2C2C2E, hairline rgba(84,84,88,0.36), and let glass panels blur real content rather than blackness.
7. Modal overlay bleed. The dimmed background behind the Settings sheet still shows the page title at near-full brightness. Overlay should be rgba(0,0,0,0.55) plus backdrop blur so the sheet clearly owns focus.
8. Scrollbar styling inside sheets is default browser chrome; style thin overlay scrollbars consistent with the theme.

## Constraints, non-negotiable

- Single self-contained file. Keep inline CSS and JS, no external assets beyond the existing pinned import map (three 0.180.0, Spark 2.1.0 URLs must not change).
- Do not break behavior. Every element id, data attribute, and class referenced by the JavaScript must keep working. Prefer CSS-only changes; restructure markup only where the JS does not reference it, and re-check each querySelector against the new markup if you do.
- The JS logic, API calls, and SSE handling stay as they are. This is a visual and spatial pass, not a rewrite.
- Zero code comments anywhere. No em-dash characters anywhere.
- Respect prefers-reduced-motion. Animations use transform and opacity only.
- Design language: iOS 26 spirit. SF-style system font stack, frosted glass, large collapsing titles, segmented controls, pill buttons, spring easing cubic-bezier(.32,.72,0,1), accent #0A84FF, success #30D158, warning #FF9F0A, danger #FF453A. Library view keeps its Pinterest masonry.
- Test both themes: light #F2F2F7 background and the dark scheme above, plus widths 1024 to 2560.

## Definition of done

At 1920x1080 dark mode: title and content share one grid, tab bar fully visible with clearance, wizard steps sit on elevated cards with even 8pt rhythm, settings rows truncate cleanly, nothing clips, nothing floats unanchored.
