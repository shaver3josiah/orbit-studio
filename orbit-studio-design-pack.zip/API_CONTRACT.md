# Backend contract the UI depends on

Base http://127.0.0.1:7360. Do not rename or remove any fetch usage.

GET /api/health, GET /api/doctor, GET /api/projects, POST /api/projects
GET|DELETE /api/projects/{id}
POST /api/projects/{id}/media (multipart file, ?force=1 override on not_equirectangular)
POST /api/projects/{id}/run {stage: frames|reframe|bundle|local_train, settings}
POST /api/projects/{id}/cancel
GET /api/events (SSE, data:{id,stage,pct,line,state})
GET /api/projects/{id}/bundle.zip
POST /api/projects/{id}/result (multipart, .ply .splat .spz)
GET /api/projects/{id}/artifact.splat|.spz|.ply
POST /api/projects/{id}/poster {dataUrl}, GET /api/projects/{id}/poster.jpg
GET|POST /api/projects/{id}/keyframes
GET /api/projects/{id}/crops, GET /api/projects/{id}/crops/{name}
GET /demo/demo.splat, GET /notebooks/{name}, GET /docs/{name}

Player internals to leave intact: the module script's three.js and Spark setup, canvas recording (captureStream(0) plus requestFrame), keyframe strip logic, SSE console. The file gate for file:// protocol must remain.
